#Acknowledgement
#KNN method is inspired by the blog from https://www.jianshu.com/p/cd44e93e3062
#NB method is inspired by the blog from https://blog.csdn.net/qq_41398808/article/details/92087810
#https://geek-docs.com/machine-learning/classification-algorithms/gaussian-naive-bayes.html
import numpy as np
from collections import Counter
import csv
import sys
import math
train_file=sys.argv[1]        #get the arguement from the commend line
test_file=sys.argv[2]
algorithm=sys.argv[3]
PA_length=0

#Read the number of attributes
def read_n(FileName):
    fr = open(FileName)
    lines = fr.readlines()
    lines[1].strip()
    test=lines[1].split(',')
    #print(test)
    n=len(test)-1
    return n

#Read the file
def file_reading(FileName, parammterNumber):
    fr = open(FileName)
    lines = fr.readlines()
    lineNums = len(lines)
    resultMat = np.zeros((lineNums, parammterNumber))
    LabelVector = []
    for i in range(lineNums):
        line = lines[i].strip()
        itemMat = line.split(',')
        resultMat[i, :] = itemMat[0:parammterNumber]
        LabelVector.append(itemMat[-1])
    fr.close()
    return resultMat, LabelVector;

#Calculate the proability Density function
def ca_p(x, mean, variance):
    return (1 / (math.sqrt(2 * math.pi * variance))) * math.exp(-(math.pow(x - mean, 2) / (2 * variance)))


#KNN function for every example
def KNN(training,test,TR_label,k):
    distance=[]
    TR_size=training.shape[0]

    #Calculate the euclidean distance
    for i in range(TR_size):
        feature = training[i]
        euclidean_distance = np.linalg.norm(np.array(feature)-np.array(test))
        distance.append([euclidean_distance,TR_label[i]])
    sorted_distances =[i[1]  for i in sorted(distance)]
    top_nearest = sorted_distances[:k]
    group_res = Counter(top_nearest).most_common(1)[0][0]

    return group_res

PA_length=read_n(train_file)

TRM,TRclass=file_reading(train_file,PA_length)
TEM,TEclass=file_reading(test_file,PA_length)
#TEclass=[]
#print(TRM)
#print(TEclass)


def NB(training,test,TR_label):
    TR_AR_MV=[] #Training attributes mean and varience
    BufferY=[]  #Yes buffer
    BufferN=[]  #No buffer
    BufferAll=[]#Buffer for mean and varience
    TR_size=training.shape[0]
    i=0
    j=0
    while j<PA_length:
        BufferY=[]
        BufferN=[]
        BufferAll=[]
        #get each attributes mean and varience and put it in to a n*4 array in TR_AR_MV
        #[0]yes mean [1]yes varience [2]No mean [3]varience
        i=0
        while i<TR_size:
            if(TR_label[i]=='yes'):
                BufferY.append(training[i][j])
            else:
                BufferN.append(training[i][j])
            i=i+1
        BufferAll.append(np.mean(BufferY))
        BufferAll.append(np.var(BufferY))
        BufferAll.append(np.mean(BufferN))
        BufferAll.append(np.var(BufferN))
        TR_AR_MV.append(BufferAll)
        j=j+1
    #proability of yes and no
    PY=1.0
    PN=1.0
    PRY=len(BufferY)
    PRN=len(BufferN)
    index=0
    while index<PA_length:
        PY=PY*ca_p(test[index],TR_AR_MV[index][0],TR_AR_MV[index][1])
        PN=PN*ca_p(test[index],TR_AR_MV[index][2],TR_AR_MV[index][3])
        index=index+1
    #compare the PY and PN
    if PY*PRY>=PN*PRN:
        return 'yes'
    else:
        return 'no'

if(algorithm=='NB'):
    #print(" I am NB")
    #correct=0
    for i in range(TEM.shape[0]):
        res1=NB(TRM,TEM[i],TRclass)
        print(res1)
        #if res1==TEclass[i]:
        #    correct+=1
    #print(correct)
    #print(correct/TEM.shape[0])

else:
    k_in=int(algorithm[0])
    #correct=0
    testSize = TEM.shape[0]
    for i in range(testSize):
        res = KNN(TRM,TEM[i],TRclass,k_in)
        print(res)
        #if res==TEclass[i]:
        #    correct+=1
    #print(correct)
    #print(correct/testSize)


#print(KNN(TRM, [0.3,0.4,0.6,0.9,0.4,0.3,0.1,0.6], TRclass, k = 5))

#print(result)
#print(class1)
